# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ClickLogin::Application.config.secret_token = 'cd81545924ac89f669a77ec66c303a0705b5029b9e6360dbf5e6f8fa7c6a25db9fadd50cfb17eabcc9e606730c42e30480c2980414947a2b11bae4cbb57b68f6'
